import React from "react";
import Calculadora from "./calc";
import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <Calculadora description="Calculadora"/>
    </div>
  );
}
