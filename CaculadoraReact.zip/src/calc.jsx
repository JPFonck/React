import React,{useState, useEffect} from "react";
import "./styles.css";

export default function Card(props) {
  const [n1, setSuma] = useState(8);
  const [n2, setResta] = useState(2);
  const [resp, setresp] = useState(0);

  
  function sumas (){
    setresp(n1+n2);
  }
  function restas (){
    setresp(n1-n2);
  }
  function multiplicacion (){
    setresp(n1*n2);
  }
  function dividir (){
    if (n2==0)
    {
      setresp("No se puede divir para 0");
    }
    else{
      setresp(n1/n2);
    }
  }
  return (
    <div className="card-container">
      <h2>{props.description}</h2>
      <p>Valores</p>
      <p>n1:{n1}</p>
      <p>n2:{n2}</p>
      <button onClick={sumas}>Sumar</button>
      <button onClick={restas}>Restar</button>
      <button onClick={multiplicacion}>Multiplicar</button>
      <button onClick={dividir}>Dividir</button>
      <p>Respuesta: {resp}</p>
      
    </div>
  );
}